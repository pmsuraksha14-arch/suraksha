# AI Resume Analyzer

A beginner-friendly AI/ATS-style resume analyzer built with Python and Streamlit.

## Run locally

1. Install Python 3.10+.
2. Open a terminal in this folder.
3. Run:

```bash
pip install -r requirements.txt
streamlit run app.py
```

4. Open the local URL shown by Streamlit.

## Features
- Preloaded demo using the supplied Jeevitha P resume content
- ATS-style score
- Section detection
- Skill detection
- Resume improvement suggestions
- Entry-level role matching

This version is intentionally simple and does not require an API key.
