
import re
import streamlit as st

st.set_page_config(page_title="AI Resume Analyzer", page_icon="📄", layout="wide")

DEMO_RESUME = """Jeevitha P
Graduate
Karnataka - 573201
Mob No.: 6363239196
Email: jeevithap370@gmail.com

CAREER OBJECTIVE
To obtain a challenging position in a reputed organization where I can utilize my knowledge and skills learning new skills and contribute to the growth of the organisation.

ACADEMIC QUALIFICATION
10th - State board - 2021 - 71%
12th - State board - 2023 - 88%
BBA - Hassan University - 2026 - 83%

OTHER QUALIFICATION
Basic computer knowledge
Advanced Microsoft Excel
Tally Prime with GST

WORK EXPERIENCE
Fresher

PERSONAL INFORMATION
Language Known: Kannada and English
Gender: Female
Nationality: Indian
Marital Status: Unmarried
"""

SKILLS = [
    "python", "java", "c++", "c", "sql", "excel", "microsoft excel",
    "tally", "tally prime", "gst", "communication", "leadership",
    "teamwork", "problem solving", "machine learning", "data analysis",
    "power bi", "html", "css", "javascript"
]

def analyze_resume(text):
    t = text.lower()
    found = [s.title() for s in SKILLS if s in t]
    sections = {
        "Career Objective": bool(re.search(r"career objective|objective|summary", t)),
        "Education": bool(re.search(r"academic qualification|education|10th|12th|degree|bba", t)),
        "Skills": bool(re.search(r"skills|qualification|excel|tally|python|sql", t)),
        "Work Experience": bool(re.search(r"work experience|experience|fresher", t)),
        "Contact": bool(re.search(r"\b[\w.+-]+@[\w-]+\.[\w.-]+\b", t) and re.search(r"\b\d{10}\b", t)),
        "Projects": bool(re.search(r"project|projects", t)),
    }

    score = 40
    score += 10 if sections["Education"] else 0
    score += 10 if sections["Skills"] else 0
    score += 10 if sections["Work Experience"] else 0
    score += 10 if sections["Contact"] else 0
    score += 10 if sections["Career Objective"] else 0
    score += 10 if sections["Projects"] else 0
    score = min(score, 100)

    suggestions = []
    if not sections["Projects"]:
        suggestions.append("Add 1–3 academic or personal projects with tools used and measurable results.")
    if "communication" not in t:
        suggestions.append("Add relevant soft skills such as communication, teamwork and problem solving if you have them.")
    if "python" not in t:
        suggestions.append("For AI/ML roles, consider adding Python and relevant libraries if you have learned them.")
    if "linkedin" not in t:
        suggestions.append("Add a LinkedIn profile URL if you have one.")
    if "achievement" not in t and "award" not in t:
        suggestions.append("Include achievements, certifications, workshops or competitions where relevant.")
    if re.search(r"gender|nationality|marital status", t):
        suggestions.append("For many modern job applications, personal details such as gender, nationality and marital status are usually unnecessary; consider removing them unless requested.")

    return score, sections, found, suggestions

st.title("📄 AI Resume Analyzer")
st.caption("A simple Python + Streamlit project for checking resume structure, skills and ATS-style readiness.")

with st.sidebar:
    st.header("Demo Resume")
    if st.button("Load Jeevitha's Resume"):
        st.session_state["resume"] = DEMO_RESUME
    st.markdown("**Project:** AI Resume Analyzer")
    st.markdown("**Technology:** Python + Streamlit")
    st.info("This project uses rule-based analysis. It does not send resume data to an external AI service.")

resume = st.text_area(
    "Paste your resume text here",
    value=st.session_state.get("resume", DEMO_RESUME),
    height=360,
    placeholder="Paste resume content..."
)

if st.button("🔍 Analyze Resume", type="primary"):
    score, sections, skills, suggestions = analyze_resume(resume)

    st.subheader("Resume Analysis")
    c1, c2, c3 = st.columns(3)
    c1.metric("ATS-style Score", f"{score}/100")
    c2.metric("Skills Found", len(skills))
    c3.metric("Sections Found", sum(sections.values()))

    st.progress(score / 100)

    left, right = st.columns(2)
    with left:
        st.subheader("✅ Sections")
        for name, present in sections.items():
            st.write(("✅ " if present else "⚠️ ") + name)

        st.subheader("🧰 Skills Detected")
        if skills:
            st.write(", ".join(skills))
        else:
            st.write("No predefined skills detected.")

    with right:
        st.subheader("💡 Suggestions")
        if suggestions:
            for s in suggestions:
                st.write("• " + s)
        else:
            st.success("No major suggestions from this basic analyzer.")

    st.subheader("🎯 Suitable Entry-Level Roles")
    role_text = resume.lower()
    roles = []
    if "excel" in role_text or "tally" in role_text:
        roles += ["Accounts Assistant", "Office Assistant", "MIS Executive"]
    if "bba" in role_text:
        roles += ["Business Administration Trainee", "HR/Admin Assistant"]
    if "python" in role_text or "sql" in role_text:
        roles += ["Junior Data/Software Intern"]
    roles = list(dict.fromkeys(roles))
    st.write(" • ".join(roles) if roles else "Add more skills to improve role matching.")

st.divider()
st.caption("Tip: For real job applications, tailor keywords to the job description and keep claims accurate.")
