# AI Resume Analyzer

A beginner-friendly Flask website that analyzes PDF, DOCX, and TXT resumes.

## Features
- Resume upload
- ATS score
- Skills detection
- Resume section check
- Job-description keyword matching
- Missing keyword detection
- AI-style improvement suggestions
- Responsive UI

## Run locally

1. Install Python 3.10+.
2. Open a terminal in this folder.
3. Create a virtual environment (optional):
   `python -m venv venv`
4. Activate it.
5. Install dependencies:
   `pip install -r requirements.txt`
6. Start:
   `python app.py`
7. Open `http://127.0.0.1:5000`

This version uses local NLP-style rules and does not require a paid AI API.
