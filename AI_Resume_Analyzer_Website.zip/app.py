from flask import Flask, render_template, request, jsonify
from werkzeug.utils import secure_filename
import os, re

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 5 * 1024 * 1024
UPLOAD_FOLDER = "uploads"
ALLOWED = {"pdf", "docx", "txt"}
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER

SKILLS = [
    "python","java","javascript","html","css","react","node.js","sql","mysql",
    "machine learning","deep learning","artificial intelligence","nlp",
    "flask","django","git","github","excel","power bi","data analysis",
    "tensorflow","pandas","numpy","c++","communication","leadership"
]

def extract_text(path, ext):
    if ext == "txt":
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            return f.read()
    if ext == "pdf":
        try:
            from pypdf import PdfReader
            return "\n".join(page.extract_text() or "" for page in PdfReader(path).pages)
        except Exception:
            return ""
    if ext == "docx":
        try:
            from docx import Document
            return "\n".join(p.text for p in Document(path).paragraphs)
        except Exception:
            return ""
    return ""

def analyze(text, job_description=""):
    lower = text.lower()
    found = [s for s in SKILLS if s in lower]
    sections = {
        "Contact information": bool(re.search(r"[\w\.-]+@[\w\.-]+\.\w+", text)),
        "Education": bool(re.search(r"\b(education|b\.?tech|bachelor|master|degree|university|college)\b", lower)),
        "Experience": bool(re.search(r"\b(experience|internship|work history|employment)\b", lower)),
        "Projects": "project" in lower,
        "Skills": "skill" in lower,
        "Certifications": "certif" in lower
    }
    section_score = sum(sections.values()) / len(sections) * 30
    skill_score = min(len(found) / 10, 1) * 25
    keyword_score = min(len(re.findall(r"\b[a-zA-Z]{4,}\b", text)) / 250, 1) * 15
    formatting_score = 20 if len(text) >= 500 else 10 if len(text) >= 200 else 5
    action_score = 10 if re.search(r"\b(developed|created|managed|designed|implemented|led|built|analyzed)\b", lower) else 4
    ats = round(section_score + skill_score + keyword_score + formatting_score + action_score)

    job_words = set(re.findall(r"\b[a-zA-Z][a-zA-Z+#.-]{2,}\b", job_description.lower()))
    resume_words = set(re.findall(r"\b[a-zA-Z][a-zA-Z+#.-]{2,}\b", lower))
    meaningful = {w for w in job_words if w not in {"the","and","with","for","from","that","this","your","you","are","will","our"}}
    matched = sorted(meaningful & resume_words)
    missing = sorted(meaningful - resume_words)[:15]
    match = round(len(matched)/len(meaningful)*100) if meaningful else 0

    suggestions = []
    if not sections["Contact information"]: suggestions.append("Add a professional email address and contact details.")
    if not sections["Skills"]: suggestions.append("Add a dedicated Skills section with relevant technical and soft skills.")
    if not sections["Projects"]: suggestions.append("Add 2–3 relevant projects with measurable outcomes.")
    if not sections["Experience"]: suggestions.append("Add internship, work, volunteer, or practical experience where applicable.")
    if not sections["Certifications"]: suggestions.append("Add relevant certifications or courses if you have them.")
    if len(found) < 5: suggestions.append("Add more job-relevant keywords and skills that you genuinely possess.")
    if not re.search(r"\b(developed|created|managed|designed|implemented|led|built|analyzed)\b", lower):
        suggestions.append("Use strong action verbs such as developed, implemented, analyzed, and led.")
    if not suggestions: suggestions.append("Your resume has a solid structure. Tailor keywords and achievements for each target role.")

    return {
        "ats": max(0, min(100, ats)),
        "skills": found,
        "sections": sections,
        "matched": matched[:15],
        "missing": missing,
        "job_match": match,
        "suggestions": suggestions
    }

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/analyze", methods=["POST"])
def analyze_resume():
    if "resume" not in request.files:
        return jsonify({"error": "Please upload a resume."}), 400
    file = request.files["resume"]
    if not file.filename:
        return jsonify({"error": "Please choose a file."}), 400
    ext = file.filename.rsplit(".", 1)[-1].lower() if "." in file.filename else ""
    if ext not in ALLOWED:
        return jsonify({"error": "Supported formats: PDF, DOCX, TXT."}), 400

    filename = secure_filename(file.filename)
    path = os.path.join(app.config["UPLOAD_FOLDER"], filename)
    file.save(path)
    text = extract_text(path, ext)
    if not text.strip():
        return jsonify({"error": "Could not extract readable text. Try a text-based PDF/DOCX or TXT file."}), 400
    result = analyze(text, request.form.get("job_description", ""))
    result["filename"] = filename
    return jsonify(result)

if __name__ == "__main__":
    app.run(debug=True)
