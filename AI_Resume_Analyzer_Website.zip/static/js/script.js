const form=document.getElementById("resumeForm"), input=document.getElementById("resume"), drop=document.getElementById("dropzone");
input.addEventListener("change",()=>showFile(input.files[0]));
["dragenter","dragover"].forEach(e=>drop.addEventListener(e,x=>{x.preventDefault();drop.style.borderColor="#5b5ce2"}));
["dragleave","drop"].forEach(e=>drop.addEventListener(e,x=>{x.preventDefault();drop.style.borderColor="#cfd3df"}));
drop.addEventListener("drop",e=>{input.files=e.dataTransfer.files;showFile(input.files[0])});
function showFile(f){document.getElementById("filename").textContent=f?`Selected: ${f.name}`:"";}

form.addEventListener("submit",async e=>{
 e.preventDefault(); if(!input.files[0]) return showError("Please upload a resume first.");
 document.getElementById("error").classList.add("hidden");document.getElementById("results").classList.add("hidden");document.getElementById("loading").classList.remove("hidden");
 try{
  const r=await fetch("/analyze",{method:"POST",body:new FormData(form)}), data=await r.json();
  if(!r.ok) throw new Error(data.error||"Analysis failed.");
  render(data);
 }catch(err){showError(err.message)}finally{document.getElementById("loading").classList.add("hidden")}
});
function showError(t){const e=document.getElementById("error");e.textContent=t;e.classList.remove("hidden")}
function chips(id,arr,missing=false){const el=document.getElementById(id);el.innerHTML=arr.length?arr.map(x=>`<span class="chip ${missing?"missing":""}">${x}</span>`).join(""):"<span class='muted'>None found</span>"}
function render(d){
 document.getElementById("results").classList.remove("hidden");
 document.getElementById("resultFile").textContent=d.filename;
 document.getElementById("ats").textContent=d.ats;document.getElementById("atsBar").style.width=d.ats+"%";
 document.getElementById("match").textContent=d.job_match+"%";document.getElementById("skillCount").textContent=d.skills.length;
 chips("skills",d.skills);chips("matched",d.matched);chips("missing",d.missing,true);
 document.getElementById("sections").innerHTML=Object.entries(d.sections).map(([k,v])=>`<div class="section-line"><span>${k}</span><b class="${v?"ok":"no"}">${v?"✓ Complete":"○ Missing"}</b></div>`).join("");
 document.getElementById("suggestions").innerHTML=d.suggestions.map(s=>`<li>${s}</li>`).join("");
 document.getElementById("results").scrollIntoView({behavior:"smooth"});
}
document.getElementById("newBtn").addEventListener("click",()=>{document.getElementById("results").classList.add("hidden");form.reset();document.getElementById("filename").textContent="";document.getElementById("analyzer").scrollIntoView({behavior:"smooth"})});
